prob = [2**i for i in range(3, 23)]

## warning, don't remove 0, main.py doesn't rectify
procs = [0, 4, 8, 12, 16]
